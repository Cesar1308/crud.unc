    <footer class="footer">
        CRUD PHP - MYSQL
    </footer>
</body>
</html>