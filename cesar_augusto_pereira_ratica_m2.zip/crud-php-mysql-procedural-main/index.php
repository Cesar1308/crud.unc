<?php header('location: src/pages/user/read.php'); ?>
